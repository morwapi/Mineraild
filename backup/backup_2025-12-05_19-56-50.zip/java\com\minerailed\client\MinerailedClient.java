package com.minerailed.client;

import com.minerailed.MinerailedMod;
import net.fabricmc.api.ClientModInitializer;

/**
 * クライアント専用の初期化処理
 * レンダリング、HUD、キー操作などクライアントサイドのみで実行される処理を管理
 */
public class MinerailedClient implements ClientModInitializer {

    /**
     * クライアント初期化処理
     */
    @Override
    public void onInitializeClient() {
        MinerailedMod.LOGGER.info("Minerailed クライアント初期化中...");

        // TODO: HUDレンダラーの登録
        // TODO: キーバインドの登録
        // TODO: パーティクル効果の登録

        MinerailedMod.LOGGER.info("Minerailed クライアント初期化完了");
    }
}
