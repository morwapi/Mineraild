package com.minerailed.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.world.World;

/**
 * 機関車エンティティ - 第1段階（豚ベース）
 * 
 * 成長段階に応じて豚→牛→ラヴェジャーと変化する機関車の基盤
 * 現在は最もシンプルな豚バージョンのみを実装
 */
public class LocomotiveEntity extends PigEntity {

    /**
     * 現在の成長段階
     * 0 = 豚（初期）
     * 1 = 牛（中級）
     * 2 = ラヴェジャー（上級）
     */
    private int growthStage = 0;

    /**
     * 設置したレールの総数（成長条件）
     */
    private int railsPlaced = 0;

    /**
     * 移動速度（ユーザー調整可能）
     */
    private float trainSpeed = 0.1f;

    public LocomotiveEntity(EntityType<? extends PigEntity> entityType, World world) {
        super(entityType, world);
        // 豚の通常の振る舞いを無効化
        this.setPersistent();
    }

    /**
     * エンティティのTick処理
     * 重い処理は避け、必要最小限の更新のみ実行
     */
    @Override
    public void tick() {
        super.tick();

        // サーバー側のみで処理
        if (this.getWorld().isClient) {
            return;
        }

        // TODO: レールに沿った移動ロジック
        // TODO: 成長条件チェック
    }

    /**
     * レール設置数を追加
     * 
     * @param count 追加するレール数
     */
    public void addRailsPlaced(int count) {
        this.railsPlaced += count;
        checkGrowth();
    }

    /**
     * 成長条件をチェックして段階を更新
     */
    private void checkGrowth() {
        int newStage = growthStage;

        if (railsPlaced >= 301) {
            newStage = 2; // ラヴェジャー
        } else if (railsPlaced >= 101) {
            newStage = 1; // 牛
        }

        if (newStage != growthStage) {
            growthStage = newStage;
            // TODO: エンティティのビジュアル変更
            // TODO: パーティクル効果
        }
    }

    /**
     * 列車速度を設定
     * 
     * @param speed 新しい速度（0.0f - 1.0f）
     */
    public void setTrainSpeed(float speed) {
        this.trainSpeed = Math.max(0.0f, Math.min(1.0f, speed));
    }

    /**
     * 現在の成長段階を取得
     * 
     * @return 0=豚、1=牛、2=ラヴェジャー
     */
    public int getGrowthStage() {
        return growthStage;
    }
}
