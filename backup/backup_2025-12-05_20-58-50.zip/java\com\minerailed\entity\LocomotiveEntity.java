package com.minerailed.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.RailBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * 機関車エンティティ - 第1段階（豚ベース）
 * 
 * 成長段階に応じて豚→牛→ラヴェジャーと変化する機関車の基盤
 * 現在は最もシンプルな豚バージョンのみを実装
 */
public class LocomotiveEntity extends PigEntity {

    /**
     * 現在の成長段階
     * 0 = 豚（初期）
     * 1 = 牛（中級）
     * 2 =ラヴェジャー（上級）
     */
    private int growthStage = 0;

    /**
     * 設置したレールの総数（成長条件）
     */
    private int railsPlaced = 0;

    /**
     * 移動速度（ユーザー調整可能）
     */
    private float trainSpeed = 0.1f;

    /**
     * レール移動が有効かどうか
     */
    private boolean autoMoveEnabled = true;

    /**
     * 移動チェック間隔（Tick処理を軽量化）
     */
    private int moveCheckCounter = 0;

    public LocomotiveEntity(EntityType<? extends PigEntity> entityType, World world) {
        super(entityType, world);
        // 持続性を設定（デスポーンしない）
        this.setPersistent();
    }

    /**
     * エンティティのTick処理
     * 重い処理は避け、必要最小限の更新のみ実行
     */
    @Override
    public void tick() {
        super.tick();

        // サーバー側のみで処理
        if (this.getWorld().isClient) {
            return;
        }

        // 自動移動が無効なら何もしない
        if (!autoMoveEnabled) {
            return;
        }

        // 10 Tickごとにチェック（処理軽量化）
        moveCheckCounter++;
        if (moveCheckCounter < 10) {
            return;
        }
        moveCheckCounter = 0;

        // レール上にいるかチェックして移動
        tryMoveOnRail();
    }

    /**
     * レール上での移動を試みる
     */
    private void tryMoveOnRail() {
        BlockPos currentPos = this.getBlockPos();
        BlockState blockState = this.getWorld().getBlockState(currentPos);

        // レールブロックかチェック（Null安全性）
        if (blockState == null || !(blockState.getBlock() instanceof RailBlock)) {
            // 足元がレールでない場合、1ブロック下もチェック
            BlockPos belowPos = currentPos.down();
            blockState = this.getWorld().getBlockState(belowPos);

            if (blockState == null || !(blockState.getBlock() instanceof RailBlock)) {
                // レールが見つからない場合は停止
                this.setVelocity(Vec3d.ZERO);
                return;
            }
            currentPos = belowPos;
        }

        // レールの方向を取得
        Direction railDirection = getRailDirection(blockState);

        if (railDirection != null) {
            // レールの方向に移動
            Vec3d movement = Vec3d.of(railDirection.getVector()).multiply(trainSpeed);
            this.setVelocity(movement.x, this.getVelocity().y, movement.z);

            // 向きも更新
            this.setYaw(railDirection.asRotation());
        }
    }

    /**
     * レールブロックから進行方向を取得
     * 
     * @param blockState レールブロックの状態
     * @return 進行方向（nullの場合は方向不明）
     */
    private Direction getRailDirection(BlockState blockState) {
        if (!(blockState.getBlock() instanceof RailBlock)) {
            return null;
        }

        // レールの形状に基づいて方向を決定
        // とりあえずシンプルに北方向に進む（後で改善）
        return Direction.NORTH;
    }

    /**
     * レール設置数を追加
     * 
     * @param count 追加するレール数
     */
    public void addRailsPlaced(int count) {
        this.railsPlaced += count;
        checkGrowth();
    }

    /**
     * 成長条件をチェックして段階を更新
     */
    private void checkGrowth() {
        int newStage = growthStage;

        if (railsPlaced >= 301) {
            newStage = 2; // ラヴェジャー
        } else if (railsPlaced >= 101) {
            newStage = 1; // 牛
        }

        if (newStage != growthStage) {
            growthStage = newStage;
            // TODO: エンティティのビジュアル変更
            // TODO: パーティクル効果
        }
    }

    /**
     * 列車速度を設定
     * 
     * @param speed 新しい速度（0.0f - 1.0f）
     */
    public void setTrainSpeed(float speed) {
        this.trainSpeed = Math.max(0.0f, Math.min(1.0f, speed));
    }

    /**
     * 現在の成長段階を取得
     * 
     * @return 0=豚、1=牛、2=ラヴェジャー
     */
    public int getGrowthStage() {
        return growthStage;
    }
}
