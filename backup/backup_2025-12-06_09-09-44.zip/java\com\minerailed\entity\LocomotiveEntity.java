package com.minerailed.entity;

import net.minecraft.block.BlockState;
import net.minecraft.block.RailBlock;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 機関車エンティティ - 第1段階（豚ベース）
 * 
 * 成長段階に応じて豚→牛→ラヴェジャーと変化する機関車の基盤
 * 車両連結システムを含む
 */
public class LocomotiveEntity extends PigEntity {

    /** 最大連結車両数（機関車含まず） */
    private static final int MAX_COUPLED_CARTS = 5;

    /** 連結距離の最大値 */
    private static final double MAX_COUPLING_DISTANCE = 3.0;

    private int growthStage = 0;
    private int railsPlaced = 0;
    private float trainSpeed = 0.1f;
    private boolean autoMoveEnabled = true;
    private int moveCheckCounter = 0;

    // カーブでの連続方向転換を防ぐ
    private Direction lastDirection = null;
    private int directionChangeCooldown = 0;

    // 連結された車両のリスト
    private final List<UUID> coupledCartUUIDs = new ArrayList<>();
    private final List<Entity> coupledCarts = new ArrayList<>();

    public LocomotiveEntity(EntityType<? extends PigEntity> entityType, World world) {
        super(entityType, world);
        this.setPersistent();

        // 連結リストを明示的に初期化
        coupledCartUUIDs.clear();
        coupledCarts.clear();
    }

    @Override
    protected void initGoals() {
        // AIゴールをクリアして豚が勝手に動かないようにする
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient || !autoMoveEnabled) {
            return;
        }

        moveCheckCounter++;
        if (moveCheckCounter < 10) {
            return;
        }
        moveCheckCounter = 0;

        tryMoveOnRail();
        moveCoupledCarts();
    }

    private void tryMoveOnRail() {
        // クールダウン中は方向を変えない
        if (directionChangeCooldown > 0) {
            directionChangeCooldown--;
        }

        BlockPos currentPos = this.getBlockPos();
        BlockState blockState = this.getWorld().getBlockState(currentPos);

        if (blockState == null || !(blockState.getBlock() instanceof RailBlock)) {
            BlockPos belowPos = currentPos.down();
            blockState = this.getWorld().getBlockState(belowPos);

            if (blockState == null || !(blockState.getBlock() instanceof RailBlock)) {
                this.setVelocity(Vec3d.ZERO);
                return;
            }
        }

        Direction railDirection = getRailDirection(blockState);

        if (railDirection != null) {
            // 方向が変わった場合、クールダウンを設定
            if (lastDirection != null && lastDirection != railDirection) {
                if (directionChangeCooldown > 0) {
                    // クールダウン中は前回の方向を維持
                    railDirection = lastDirection;
                } else {
                    // 方向変更を許可し、クールダウンを開始
                    directionChangeCooldown = 20; // 2秒間（20 Tick）
                    lastDirection = railDirection;
                }
            } else {
                lastDirection = railDirection;
            }

            Vec3d movement = Vec3d.of(railDirection.getVector()).multiply(trainSpeed);
            this.setVelocity(movement.x, this.getVelocity().y, movement.z);
            this.setYaw(railDirection.asRotation());
        }
    }

    /**
     * 連結された車両を機関車と一緒に動かす
     */
    private void moveCoupledCarts() {
        if (coupledCartUUIDs.isEmpty()) {
            return;
        }

        // UUIDからエンティティを復元（まだの場合）
        if (coupledCarts.isEmpty() && !coupledCartUUIDs.isEmpty()) {
            resolveCartReferences();
        }

        Vec3d locoPos = this.getPos();
        Vec3d locoVelocity = this.getVelocity();

        // 各車両を機関車の後ろに配置
        for (int i = 0; i < coupledCarts.size(); i++) {
            Entity cart = coupledCarts.get(i);
            if (cart == null || !cart.isAlive()) {
                continue;
            }

            // 車両の位置を計算（機関車の後ろに1.5ブロックずつ離して配置）
            double offset = -1.5 * (i + 1);
            Vec3d targetPos = locoPos.add(
                    lastDirection != null ? Vec3d.of(lastDirection.getVector()).multiply(offset)
                            : new Vec3d(0, 0, offset));

            // 車両を目標位置に移動
            cart.setPosition(targetPos.x, cart.getY(), targetPos.z);
            cart.setVelocity(locoVelocity);

            // 向きも同期
            cart.setYaw(this.getYaw());
        }
    }

    /**
     * UUIDから実際のエンティティ参照を解決
     */
    private void resolveCartReferences() {
        coupledCarts.clear();
        for (UUID uuid : coupledCartUUIDs) {
            Entity entity = ((net.minecraft.server.world.ServerWorld) this.getWorld()).getEntity(uuid);
            if (entity != null && entity instanceof AbstractMinecartEntity) {
                coupledCarts.add(entity);
            }
        }
    }

    /**
     * 車両を連結
     * 
     * @param cart 連結する車両
     * @return 連結成功したらtrue
     */
    public boolean addCoupledCart(Entity cart) {
        // Null安全性チェック
        if (cart == null || !(cart instanceof AbstractMinecartEntity)) {
            return false;
        }

        // 最大数チェック
        if (coupledCartUUIDs.size() >= MAX_COUPLED_CARTS) {
            return false;
        }

        // 既に連結済みかチェック
        if (coupledCartUUIDs.contains(cart.getUuid())) {
            return false;
        }

        // 距離チェック
        if (this.squaredDistanceTo(cart) > MAX_COUPLING_DISTANCE * MAX_COUPLING_DISTANCE) {
            return false;
        }

        // 連結実行
        coupledCartUUIDs.add(cart.getUuid());
        coupledCarts.add(cart);

        com.minerailed.MinerailedMod.LOGGER.info("車両連結: " + cart.getUuid());
        return true;
    }

    /**
     * 車両を解除
     * 
     * @param cart 解除する車両
     */
    public void removeCoupledCart(Entity cart) {
        if (cart == null) {
            return;
        }

        coupledCartUUIDs.remove(cart.getUuid());
        coupledCarts.remove(cart);

        com.minerailed.MinerailedMod.LOGGER.info("車両解除: " + cart.getUuid());
    }

    /**
     * 指定されたエンティティが連結されているかチェック
     */
    public boolean isCoupled(Entity cart) {
        boolean result = cart != null && coupledCartUUIDs.contains(cart.getUuid());
        com.minerailed.MinerailedMod.LOGGER.info("isCoupledチェック: cart=" + (cart != null ? cart.getUuid() : "null")
                + ", result=" + result + ", リストサイズ=" + coupledCartUUIDs.size());
        return result;
    }

    /**
     * 連結された車両の数を取得
     */
    public int getCoupledCartCount() {
        return coupledCartUUIDs.size();
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);

        // 連結車両のUUIDを保存
        NbtList cartList = new NbtList();
        for (UUID uuid : coupledCartUUIDs) {
            NbtCompound cartNbt = new NbtCompound();
            cartNbt.putUuid("UUID", uuid);
            cartList.add(cartNbt);
        }
        nbt.put("CoupledCarts", cartList);

        // その他のデータ
        nbt.putInt("GrowthStage", growthStage);
        nbt.putInt("RailsPlaced", railsPlaced);
        nbt.putFloat("TrainSpeed", trainSpeed);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);

        // 連結車両のUUIDを読み込み
        coupledCartUUIDs.clear();
        coupledCarts.clear(); // エンティティ参照もクリア

        NbtList cartList = nbt.getList("CoupledCarts", 10); // 10 = NBT_COMPOUND
        for (int i = 0; i < cartList.size(); i++) {
            NbtCompound cartNbt = cartList.getCompound(i);
            UUID uuid = cartNbt.getUuid("UUID");
            coupledCartUUIDs.add(uuid);
        }

        // その他のデータ
        this.growthStage = nbt.getInt("GrowthStage");
        this.railsPlaced = nbt.getInt("RailsPlaced");
        this.trainSpeed = nbt.getFloat("TrainSpeed");
    }

    private Direction getRailDirection(BlockState blockState) {
        if (!(blockState.getBlock() instanceof RailBlock)) {
            return null;
        }

        RailBlock railBlock = (RailBlock) blockState.getBlock();

        try {
            RailShape shape = blockState.get(railBlock.getShapeProperty());
            Vec3d velocity = this.getVelocity();
            Direction currentDirection = getDirectionFromVelocity(velocity);
            return getDirectionFromRailShape(shape, currentDirection);
        } catch (Exception e) {
            return Direction.NORTH;
        }
    }

    private Direction getDirectionFromVelocity(Vec3d velocity) {
        if (Math.abs(velocity.x) < 0.01 && Math.abs(velocity.z) < 0.01) {
            return Direction.fromRotation(this.getYaw());
        }

        double absX = Math.abs(velocity.x);
        double absZ = Math.abs(velocity.z);

        if (absX > absZ) {
            return velocity.x > 0 ? Direction.EAST : Direction.WEST;
        } else {
            return velocity.z > 0 ? Direction.SOUTH : Direction.NORTH;
        }
    }

    private Direction getDirectionFromRailShape(RailShape shape, Direction currentDirection) {
        switch (shape) {
            case NORTH_SOUTH:
                // 南北直線：南か北のみ
                return (currentDirection == Direction.SOUTH) ? Direction.SOUTH : Direction.NORTH;

            case EAST_WEST:
                // 東西直線：東か西のみ
                return (currentDirection == Direction.WEST) ? Direction.WEST : Direction.EAST;

            case ASCENDING_NORTH:
                return Direction.NORTH;
            case ASCENDING_SOUTH:
                return Direction.SOUTH;
            case ASCENDING_EAST:
                return Direction.EAST;
            case ASCENDING_WEST:
                return Direction.WEST;

            case SOUTH_EAST:
                // 南東カーブ：南→東、東→南のみ
                if (currentDirection == Direction.SOUTH) {
                    return Direction.EAST;
                } else if (currentDirection == Direction.EAST) {
                    return Direction.SOUTH;
                }
                // 不正な方向からの進入：現在の方向を維持
                return currentDirection;

            case SOUTH_WEST:
                // 南西カーブ：南→西、西→南のみ
                if (currentDirection == Direction.SOUTH) {
                    return Direction.WEST;
                } else if (currentDirection == Direction.WEST) {
                    return Direction.SOUTH;
                }
                return currentDirection;

            case NORTH_WEST:
                // 北西カーブ：北→西、西→北のみ
                if (currentDirection == Direction.NORTH) {
                    return Direction.WEST;
                } else if (currentDirection == Direction.WEST) {
                    return Direction.NORTH;
                }
                return currentDirection;

            case NORTH_EAST:
                // 北東カーブ：北→東、東→北のみ
                if (currentDirection == Direction.NORTH) {
                    return Direction.EAST;
                } else if (currentDirection == Direction.EAST) {
                    return Direction.NORTH;
                }
                return currentDirection;

            default:
                return currentDirection;
        }
    }

    public void addRailsPlaced(int count) {
        this.railsPlaced += count;
        checkGrowth();
    }

    private void checkGrowth() {
        int newStage = growthStage;
        if (railsPlaced >= 301) {
            newStage = 2;
        } else if (railsPlaced >= 101) {
            newStage = 1;
        }
        if (newStage != growthStage) {
            growthStage = newStage;
        }
    }

    public void setTrainSpeed(float speed) {
        this.trainSpeed = Math.max(0.0f, Math.min(1.0f, speed));
    }

    public int getGrowthStage() {
        return growthStage;
    }
}
