package com.minerailed.client.renderer;

import com.minerailed.entity.LocomotiveEntity;
import net.minecraft.class_5617;
import net.minecraft.class_932;

/**
 * 機関車エンティティのレンダラー
 * 現在は豚のレンダラーをそのまま使用
 */
public class LocomotiveEntityRenderer extends class_932 {

    public LocomotiveEntityRenderer(class_5617.class_5618 context) {
        super(context);
    }
}
