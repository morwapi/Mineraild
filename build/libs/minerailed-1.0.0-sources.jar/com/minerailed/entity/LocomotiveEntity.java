package com.minerailed.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1452;
import net.minecraft.class_1688;
import net.minecraft.class_1694;
import net.minecraft.class_1696;
import net.minecraft.class_1701;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2443;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3222;
import net.minecraft.class_3489;

/**
 * 機関車エンティティ - 第1段階（豚ベース）
 * 
 * 成長段階に応じて豚→牛→ラヴェジャーと変化する機関車の基盤
 * 車両連結システムを含む
 */
public class LocomotiveEntity extends class_1452 {

    /** 最大連結車両数（機関車含まず） */
    private static final int MAX_COUPLED_CARTS = 5;

    /** 連結距離の最大値 */
    private static final double MAX_COUPLING_DISTANCE = 3.0;

    private int growthStage = 0;
    private int railsPlaced = 0;
    private float trainSpeed = 0.04f;
    private boolean autoMoveEnabled = true;
    private int moveCheckCounter = 0;

    // カーブでの連続方向転換を防ぐ
    private class_2350 lastDirection = null;
    private int directionChangeCooldown = 0;

    // クラフト関連
    private int craftingCooldown = 0;
    private static final int CRAFTING_INTERVAL_TICKS = 100; // 5秒ごとにチェック

    // TNT配布関連
    private int tntDistributionTimer = 0;
    private static final int TNT_DISTRIBUTION_INTERVAL = 3600; // 3分 = 20t * 60s * 3

    // 連結クールダウン（二重クリック/イベント防止）
    private long lastCouplingTime = 0;
    private static final long COUPLING_COOLDOWN_MS = 500;

    // 連結された車両のリスト
    private final List<UUID> coupledCartUUIDs = new ArrayList<>();
    private final List<class_1297> coupledCarts = new ArrayList<>();

    public LocomotiveEntity(class_1299<? extends class_1452> entityType, class_1937 world) {
        super(entityType, world);
        this.method_5971();

        // 連結リストを明示的に初期化
        coupledCartUUIDs.clear();
        coupledCarts.clear();
        com.minerailed.MinerailedMod.LOGGER.info("機関車生成: UUID=" + this.method_5667() + ", 連結リスト初期化完了");
    }

    @Override
    protected void method_5959() {
        // AIゴールをクリアして豚が勝手に動かないようにする
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (this.method_37908().field_9236 || !autoMoveEnabled) {
            return;
        }

        // リストの同期チェック（不整合がある場合、再解決を試みる）
        if (coupledCarts.size() != coupledCartUUIDs.size()) {
            resolveCartReferences();
        }

        // 移動更新頻度制限を撤廃（滑らかな移動）
        // moveCheckCounter++;
        // if (moveCheckCounter < 10) {
        // return;
        // }
        // moveCheckCounter = 0;

        tryMoveOnRail();
        moveCoupledCarts(); // 毎Tick更新
        handleCrafting(); // 自動クラフト処理
        handleTntDistribution(); // TNT配布処理
    }

    /**
     * TNTトロッコが連結されている場合、定期的にTNTを配布
     */
    private void handleTntDistribution() {
        boolean hasTntCart = false;
        for (class_1297 cart : coupledCarts) {
            if (cart instanceof class_1701) {
                hasTntCart = true;
                break;
            }
        }

        if (hasTntCart) {
            tntDistributionTimer++;
            if (tntDistributionTimer >= TNT_DISTRIBUTION_INTERVAL) {
                tntDistributionTimer = 0;
                distributeItemToAllPlayers(new class_1799(class_1802.field_8626, 1));
                com.minerailed.MinerailedMod.LOGGER.info("TNT定期配布実行");
            }
        } else {
            // TNTカートがない場合はタイマーリセット
            tntDistributionTimer = 0;
        }
    }

    /**
     * 全プレイヤーにアイテムを配布
     */
    private void distributeItemToAllPlayers(class_1799 stack) {
        if (this.method_37908().field_9236)
            return;

        net.minecraft.server.MinecraftServer server = this.method_37908().method_8503();
        if (server == null)
            return;

        List<class_3222> players = server.method_3760().method_14571();
        for (class_3222 player : players) {
            class_1799 toGive = stack.method_7972();
            if (!player.method_31548().method_7394(toGive)) {
                // インベントリに入らない場合はドロップ
                player.method_7328(toGive, false);
            }
        }
    }

    /**
     * 自動クラフト処理
     * チェスト付きトロッコとカマド付きトロッコが連結されている場合、
     * 原木と鉄の原石からレールを製造する
     */
    private void handleCrafting() {
        if (craftingCooldown > 0) {
            craftingCooldown--;
            return;
        }

        // リセット
        craftingCooldown = CRAFTING_INTERVAL_TICKS;

        // 必要な車両があるかチェック
        boolean hasFurnace = false;
        List<class_1694> chestCarts = new ArrayList<>();

        for (class_1297 cart : coupledCarts) {
            if (cart instanceof class_1696) {
                hasFurnace = true;
            } else if (cart instanceof class_1694) {
                chestCarts.add((class_1694) cart);
            }
        }

        if (!hasFurnace || chestCarts.isEmpty()) {
            return;
        }

        // 材料を探して消費
        // 必要素材: 原木(Logs) x3, 鉄の原石(Raw Iron) x3 -> レール(Rail) x1
        // ※バニラのレシピは鉄インゴットだが、要望により原石を使用

        for (class_1694 chestCart : chestCarts) {
            class_1263 inv = chestCart; // ChestMinecartEntity implements Inventory

            int logCount = 0;
            int ironCount = 0;
            List<Integer> logSlots = new ArrayList<>();
            List<Integer> ironSlots = new ArrayList<>();

            // インベントリをスキャン
            for (int i = 0; i < inv.method_5439(); i++) {
                class_1799 stack = inv.method_5438(i);
                if (stack.method_7960())
                    continue;

                if (stack.method_31573(class_3489.field_15539)) {
                    logCount += stack.method_7947();
                    logSlots.add(i);
                } else if (stack.method_31574(class_1802.field_33400)) {
                    ironCount += stack.method_7947();
                    ironSlots.add(i);
                }
            }

            // 材料が足りているか
            if (logCount >= 3 && ironCount >= 3) {
                // 消費実行
                consumeItems(inv, logSlots, 3);
                consumeItems(inv, ironSlots, 3);

                // レール生成
                class_1799 railResult = new class_1799(class_1802.field_8129, 1);
                addStackToInventory(inv, railResult);

                // エフェクト代わりのログ/メッセージ（余裕があればパーティクルも）
                com.minerailed.MinerailedMod.LOGGER.info("レール製造完了: " + this.method_5667());
                // 1回につき1個作成でループを抜ける（複数作成したい場合は継続）
                // ここでは1サイクルで1個作成とする
                return;
            }
        }
    }

    private void consumeItems(class_1263 inv, List<Integer> slots, int countToConsume) {
        int remaining = countToConsume;
        for (int slot : slots) {
            class_1799 stack = inv.method_5438(slot);
            int take = Math.min(remaining, stack.method_7947());

            stack.method_7934(take);
            remaining -= take;

            if (remaining <= 0)
                break;
        }
    }

    private void addStackToInventory(class_1263 inv, class_1799 stack) {
        // 既存のスタックにマージ
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 slotStack = inv.method_5438(i);
            if (class_1799.method_31577(slotStack, stack)) {
                int available = slotStack.method_7914() - slotStack.method_7947();
                int move = Math.min(available, stack.method_7947());
                slotStack.method_7933(move);
                stack.method_7934(move);
                if (stack.method_7960())
                    return;
            }
        }

        // 空きスロットに入れる
        if (!stack.method_7960()) {
            for (int i = 0; i < inv.method_5439(); i++) {
                if (inv.method_5438(i).method_7960()) {
                    inv.method_5447(i, stack.method_7972());
                    stack.method_7939(0);
                    return;
                }
            }
        }

        // インベントリがいっぱいの場合は、アイテムエンティティとしてドロップする処理が必要だが
        // 簡易実装として消滅（あるいは機関車のログに出す）
        if (!stack.method_7960()) {
            com.minerailed.MinerailedMod.LOGGER.warn("インベントリが一杯でレールが入らない");
        }
    }

    private void tryMoveOnRail() {
        // クールダウン中は方向を変えない
        if (directionChangeCooldown > 0) {
            directionChangeCooldown--;
        }

        class_2338 currentPos = this.method_24515();
        class_2680 blockState = this.method_37908().method_8320(currentPos);

        if (blockState == null || !(blockState.method_26204() instanceof class_2443)) {
            class_2338 belowPos = currentPos.method_10074();
            blockState = this.method_37908().method_8320(belowPos);

            if (blockState == null || !(blockState.method_26204() instanceof class_2443)) {
                this.method_18799(class_243.field_1353);
                return;
            }
        }

        class_2350 railDirection = getRailDirection(blockState);

        if (railDirection != null) {
            // 方向が変わった場合、クールダウンを設定
            if (lastDirection != null && lastDirection != railDirection) {
                if (directionChangeCooldown > 0) {
                    // クールダウン中は前回の方向を維持
                    railDirection = lastDirection;
                } else {
                    // 方向変更を許可し、クールダウンを開始
                    directionChangeCooldown = 20; // 2秒間（20 Tick）
                    lastDirection = railDirection;
                }
            } else {
                lastDirection = railDirection;
            }

            class_243 movement = class_243.method_24954(railDirection.method_10163()).method_1021(trainSpeed);
            this.method_18800(movement.field_1352, this.method_18798().field_1351, movement.field_1350);
            this.method_36456(railDirection.method_10144());
        }
    }

    /**
     * 連結された車両を機関車と一緒に動かす
     */
    private void moveCoupledCarts() {
        if (coupledCartUUIDs.isEmpty()) {
            return;
        }

        class_243 locoPos = this.method_19538();
        class_243 locoVelocity = this.method_18798();

        // 各車両を機関車の後ろに配置
        for (int i = 0; i < coupledCarts.size(); i++) {
            class_1297 cart = coupledCarts.get(i);
            if (cart == null || !cart.method_5805()) {
                continue;
            }

            // 車両の位置を計算（機関車の後ろに1.5ブロックずつ離して配置）
            double offset = -1.5 * (i + 1);
            class_243 targetPos = locoPos.method_1019(
                    lastDirection != null ? class_243.method_24954(lastDirection.method_10163()).method_1021(offset)
                            : new class_243(0, 0, offset));

            // 車両を目標位置に移動
            cart.method_5814(targetPos.field_1352, cart.method_23318(), targetPos.field_1350);
            cart.method_18799(locoVelocity);

            // 向きも同期
            cart.method_36456(this.method_36454());
        }
    }

    /**
     * UUIDから実際のエンティティ参照を解決
     */
    private void resolveCartReferences() {
        coupledCarts.clear();
        if (coupledCartUUIDs.isEmpty())
            return;

        List<UUID> toRemove = new ArrayList<>();
        net.minecraft.class_3218 world = (net.minecraft.class_3218) this.method_37908();

        for (UUID uuid : coupledCartUUIDs) {
            class_1297 entity = world.method_14190(uuid);
            if (entity != null && entity.method_5805() && entity instanceof class_1688) {
                coupledCarts.add(entity);
            } else {
                // 見つからない場合は保持するが、長時間見つからない場合のロジックも検討必要
                // ここではデバッグログのみ
                com.minerailed.MinerailedMod.LOGGER.debug("解決失敗: UUID=" + uuid + " (Entity not found or dead)");

                // ※自己修復：もし「連結しているはず(isCoupled=true)」なのに実体がないなら、
                // プレイヤーの操作で矛盾が生じるので、本来は削除すべきか？
                // しかしチャンクロード待ちの可能性もあるので、自動削除は慎重に。
            }
        }

        // デバッグ: 解決状況
        if (coupledCarts.size() != coupledCartUUIDs.size()) {
            com.minerailed.MinerailedMod.LOGGER
                    .warn("不整合: UUIDs=" + coupledCartUUIDs.size() + ", Entities=" + coupledCarts.size());
        }
    }

    /**
     * 車両を連結
     * 
     * @param cart 連結する車両
     * @return 連結成功したらtrue
     */
    public boolean addCoupledCart(class_1297 cart) {
        // クールダウンチェック
        long now = System.currentTimeMillis();
        if (now - lastCouplingTime < COUPLING_COOLDOWN_MS) {
            return false;
        }
        lastCouplingTime = now;

        // Null安全性チェック
        if (cart == null || !(cart instanceof class_1688)) {
            return false;
        }

        // 最大数チェック
        if (coupledCartUUIDs.size() >= MAX_COUPLED_CARTS) {
            return false;
        }

        // 既に連結済みかチェック
        if (coupledCartUUIDs.contains(cart.method_5667())) {
            return false;
        }

        // 距離チェックの緩和
        // 実体に依存すると取得できない場合があるため、機関車からの距離で計算する
        // 許容距離 = 基本距離(3.0) + (連結数 * 2.0)
        double allowedDistance = MAX_COUPLING_DISTANCE + (coupledCartUUIDs.size() * 2.0);
        if (this.method_5858(cart) > allowedDistance * allowedDistance) {
            com.minerailed.MinerailedMod.LOGGER.info("連結失敗: 距離が離れすぎています (Distance="
                    + Math.sqrt(this.method_5858(cart)) + ", Allowed=" + allowedDistance + ")");
            return false;
        }

        // 連結実行
        coupledCartUUIDs.add(cart.method_5667());
        coupledCarts.add(cart); // 即時追加

        // TNTトロッコの場合、初回特典として着火具を配布
        if (cart instanceof class_1701) {
            distributeItemToAllPlayers(new class_1799(class_1802.field_8884, 1));
            com.minerailed.MinerailedMod.LOGGER.info("TNTトロッコ連結特典: 着火具配布");
        }

        com.minerailed.MinerailedMod.LOGGER
                .info("車両連結成功: CartUUID=" + cart.method_5667() + ",CurrentCount=" + coupledCartUUIDs.size());
        return true;
    }

    /**
     * 車両を解除
     * 
     * @param cart 解除する車両
     * @return 解除成功したらtrue
     */
    public boolean removeCoupledCart(class_1297 cart) {
        // クールダウンチェック
        long now = System.currentTimeMillis();
        if (now - lastCouplingTime < COUPLING_COOLDOWN_MS) {
            return false;
        }
        lastCouplingTime = now;

        if (cart == null) {
            return false;
        }

        boolean removed = coupledCartUUIDs.remove(cart.method_5667());
        coupledCarts.remove(cart);

        if (removed) {
            com.minerailed.MinerailedMod.LOGGER.info("車両解除: " + cart.method_5667());
        }
        return removed;
    }

    /**
     * 指定されたエンティティが連結されているかチェック
     */
    public boolean isCoupled(class_1297 cart) {
        boolean result = cart != null && coupledCartUUIDs.contains(cart.method_5667());
        com.minerailed.MinerailedMod.LOGGER.info("isCoupledチェック: cart=" + (cart != null ? cart.method_5667() : "null")
                + ", 機関車UUID=" + this.method_5667()
                + ", result=" + result
                + ", リストサイズ=" + coupledCartUUIDs.size());
        return result;
    }

    /**
     * 連結された車両の数を取得
     */
    public int getCoupledCartCount() {
        return coupledCartUUIDs.size();
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);

        // 連結車両のUUIDを保存
        class_2499 cartList = new class_2499();
        for (UUID uuid : coupledCartUUIDs) {
            class_2487 cartNbt = new class_2487();
            cartNbt.method_25927("UUID", uuid);
            cartList.add(cartNbt);
        }
        nbt.method_10566("CoupledCarts", cartList);

        // その他のデータ
        nbt.method_10569("GrowthStage", growthStage);
        nbt.method_10569("RailsPlaced", railsPlaced);
        nbt.method_10548("TrainSpeed", trainSpeed);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);

        // 連結車両のUUIDを読み込み
        coupledCartUUIDs.clear();
        coupledCarts.clear(); // エンティティ参照もクリア

        class_2499 cartList = nbt.method_10554("CoupledCarts", 10); // 10 = NBT_COMPOUND
        for (int i = 0; i < cartList.size(); i++) {
            class_2487 cartNbt = cartList.method_10602(i);
            UUID uuid = cartNbt.method_25926("UUID");
            coupledCartUUIDs.add(uuid);
        }

        // その他のデータ
        this.growthStage = nbt.method_10550("GrowthStage");
        this.railsPlaced = nbt.method_10550("RailsPlaced");
        this.trainSpeed = nbt.method_10583("TrainSpeed");
    }

    private class_2350 getRailDirection(class_2680 blockState) {
        if (!(blockState.method_26204() instanceof class_2443)) {
            return null;
        }

        class_2443 railBlock = (class_2443) blockState.method_26204();

        try {
            class_2768 shape = blockState.method_11654(railBlock.method_9474());
            class_243 velocity = this.method_18798();
            class_2350 currentDirection = getDirectionFromVelocity(velocity);
            return getDirectionFromRailShape(shape, currentDirection);
        } catch (Exception e) {
            return class_2350.field_11043;
        }
    }

    private class_2350 getDirectionFromVelocity(class_243 velocity) {
        if (Math.abs(velocity.field_1352) < 0.01 && Math.abs(velocity.field_1350) < 0.01) {
            return class_2350.method_10150(this.method_36454());
        }

        double absX = Math.abs(velocity.field_1352);
        double absZ = Math.abs(velocity.field_1350);

        if (absX > absZ) {
            return velocity.field_1352 > 0 ? class_2350.field_11034 : class_2350.field_11039;
        } else {
            return velocity.field_1350 > 0 ? class_2350.field_11035 : class_2350.field_11043;
        }
    }

    private class_2350 getDirectionFromRailShape(class_2768 shape, class_2350 currentDirection) {
        // デバッグログ: カーブ判定の詳細（想定外のカーブ挙動を追跡）
        if (shape != class_2768.field_12665 && shape != class_2768.field_12674 &&
                !shape.name().startsWith("ASCENDING")
                && currentDirection != getDirectionFromRailShapeInternal(shape, currentDirection)) {
            com.minerailed.MinerailedMod.LOGGER.info("カーブ判定変更: Shape=" + shape + ", InDir=" + currentDirection
                    + ", OutDir=" + getDirectionFromRailShapeInternal(shape, currentDirection));
        }
        return getDirectionFromRailShapeInternal(shape, currentDirection);
    }

    // 実際のロジックを別メソッドに分離
    private class_2350 getDirectionFromRailShapeInternal(class_2768 shape, class_2350 currentDirection) {
        switch (shape) {
            case field_12665:
                return (currentDirection == class_2350.field_11035) ? class_2350.field_11035 : class_2350.field_11043;
            case field_12674:
                return (currentDirection == class_2350.field_11039) ? class_2350.field_11039 : class_2350.field_11034;
            case field_12670:
                return class_2350.field_11043;
            case field_12668:
                return class_2350.field_11035;
            case field_12667:
                return class_2350.field_11034;
            case field_12666:
                return class_2350.field_11039;

            case field_12664:
                // 南東カーブ（南と東がつながっている）
                if (currentDirection == class_2350.field_11043)
                    return class_2350.field_11034; // 北へ進む（南から進入）→ 東へ
                if (currentDirection == class_2350.field_11039)
                    return class_2350.field_11035; // 西へ進む（東から進入）→ 南へ
                return currentDirection;

            case field_12671:
                // 南西カーブ（南と西がつながっている）
                if (currentDirection == class_2350.field_11043)
                    return class_2350.field_11039; // 北へ進む（南から進入）→ 西へ
                if (currentDirection == class_2350.field_11034)
                    return class_2350.field_11035; // 東へ進む（西から進入）→ 南へ
                return currentDirection;

            case field_12672:
                // 北西カーブ（北と西がつながっている）
                if (currentDirection == class_2350.field_11035)
                    return class_2350.field_11039; // 南へ進む（北から進入）→ 西へ
                if (currentDirection == class_2350.field_11034)
                    return class_2350.field_11043; // 東へ進む（西から進入）→ 北へ
                return currentDirection;

            case field_12663:
                // 北東カーブ（北と東がつながっている）
                if (currentDirection == class_2350.field_11035)
                    return class_2350.field_11034; // 南へ進む（北から進入）→ 東へ
                if (currentDirection == class_2350.field_11039)
                    return class_2350.field_11043; // 西へ進む（東から進入）→ 北へ
                return currentDirection;

            default:
                return currentDirection;
        }
    }

    public void addRailsPlaced(int count) {
        this.railsPlaced += count;
        checkGrowth();
    }

    private void checkGrowth() {
        int newStage = growthStage;
        if (railsPlaced >= 301) {
            newStage = 2;
        } else if (railsPlaced >= 101) {
            newStage = 1;
        }
        if (newStage != growthStage) {
            growthStage = newStage;
        }
    }

    public void setTrainSpeed(float speed) {
        this.trainSpeed = Math.max(0.0f, Math.min(1.0f, speed));
    }

    public int getGrowthStage() {
        return growthStage;
    }
}
