package com.minerailed.handler;

import com.minerailed.entity.LocomotiveEntity;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3966;
import java.util.List;

/**
 * 車両連結のためのイベントハンドラー
 * プレイヤーがトロッコをシフト+右クリックしたときに、近くの機関車と連結/解除を行う
 */
public class CouplingHandler {

    /** 機関車を探す範囲（ブロック） */
    private static final double SEARCH_RANGE = 5.0;

    /**
     * イベントハンドラーを登録
     */
    public static void register() {
        UseEntityCallback.EVENT.register(CouplingHandler::onUseEntity);
    }

    /**
     * エンティティを右クリックしたときの処理
     */
    private static class_1269 onUseEntity(class_1657 player, class_1937 world, class_1268 hand, class_1297 entity,
            class_3966 hitResult) {

        // メインハンドのみで処理（二重実行防止）
        if (hand != class_1268.field_5808) {
            return class_1269.field_5811;
        }

        // トロッコ以外は無視
        if (!(entity instanceof class_1688)) {
            return class_1269.field_5811;
        }

        // シフト+右クリックでない場合は通常の動作（乗る）
        if (!player.method_5715()) {
            return class_1269.field_5811;
        }

        class_1688 minecart = (class_1688) entity;
        com.minerailed.MinerailedMod.LOGGER
                .info("CouplingHandler: トロッコ(UUID=" + minecart.method_5667() + ")に対してシフト右クリック検知");

        // 近くの機関車を探す
        LocomotiveEntity locomotive = findNearbyLocomotive(world, minecart);

        if (locomotive == null) {
            // 機関車が見つからない
            // com.minerailed.MinerailedMod.LOGGER.info("CouplingHandler: 近くに機関車が見つかりません");
            // player.sendMessage(Text.literal("§c近くに機関車がありません（5ブロック以内）"), true);
            return class_1269.field_5811;
        }

        // クライアント側：処理成功としてマークし、バニラのGUIオープン等を防ぐ
        if (world.field_9236) {
            return class_1269.field_5812;
        }

        com.minerailed.MinerailedMod.LOGGER.info("CouplingHandler: 機関車発見(UUID=" + locomotive.method_5667() + ")");

        // 既に連結されているかチェック
        if (locomotive.isCoupled(minecart)) {
            com.minerailed.MinerailedMod.LOGGER.info("CouplingHandler: 既に連結済み -> 解除試行");
            // 連結解除
            if (locomotive.removeCoupledCart(minecart)) {
                player.method_7353(class_2561.method_43470("§a車両を解除しました"), true);
            }
            return class_1269.field_5812;
        } else {
            com.minerailed.MinerailedMod.LOGGER.info("CouplingHandler: 未連結 -> 連結試行");
            // 連結試行
            boolean success = locomotive.addCoupledCart(minecart);
            if (success) {
                player.method_7353(
                        class_2561.method_43470("§a車両を連結しました (" + locomotive.getCoupledCartCount() + "/5)"),
                        true);
                return class_1269.field_5812;
            } else {
                com.minerailed.MinerailedMod.LOGGER
                        .info("CouplingHandler: 連結失敗 (Count=" + locomotive.getCoupledCartCount() + ")");
                // 連結失敗（最大数到達など）
                if (locomotive.getCoupledCartCount() >= 5) {
                    player.method_7353(class_2561.method_43470("§c連結数が最大です（5/5)"), true);
                } else {
                    player.method_7353(class_2561.method_43470("§c連結できません（距離が遠すぎる可能性）"), true);
                }
                return class_1269.field_5814;
            }
        }
    }

    /**
     * 近くの機関車を探す
     */
    private static LocomotiveEntity findNearbyLocomotive(class_1937 world, class_1297 target) {
        class_238 searchBox = new class_238(
                target.method_23317() - SEARCH_RANGE,
                target.method_23318() - SEARCH_RANGE,
                target.method_23321() - SEARCH_RANGE,
                target.method_23317() + SEARCH_RANGE,
                target.method_23318() + SEARCH_RANGE,
                target.method_23321() + SEARCH_RANGE);

        List<LocomotiveEntity> locomotives = world.method_8390(
                LocomotiveEntity.class,
                searchBox,
                locomotive -> locomotive.method_5805());

        // 最も近い機関車を返す
        if (locomotives.isEmpty()) {
            return null;
        }

        LocomotiveEntity nearest = locomotives.get(0);
        double nearestDist = target.method_5858(nearest);

        for (LocomotiveEntity loco : locomotives) {
            double dist = target.method_5858(loco);
            if (dist < nearestDist) {
                nearest = loco;
                nearestDist = dist;
            }
        }

        return nearest;
    }
}
