package com.minerailed.item;

import com.minerailed.entity.LocomotiveEntity;
import com.minerailed.registry.ModEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

/**
 * 列車召喚アイテム
 * 右クリックで機関車エンティティを召喚する
 */
public class TrainSpawnerItem extends class_1792 {

    public TrainSpawnerItem(class_1793 settings) {
        super(settings);
    }

    /**
     * ブロックに対して使用したとき（右クリック）
     */
    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();

        com.minerailed.MinerailedMod.LOGGER.info("TrainSpawner使用: isClient=" + world.field_9236);

        // クライアント側では何もしない（サーバー側のみ処理）
        if (world.field_9236) {
            return class_1269.field_5812;
        }

        class_2338 pos = context.method_8037().method_10084(); // ブロックの上に召喚
        class_1657 player = context.method_8036();

        // Null安全性チェック
        if (player == null) {
            com.minerailed.MinerailedMod.LOGGER.warn("プレイヤーがnullです");
            return class_1269.field_5814;
        }

        try {
            com.minerailed.MinerailedMod.LOGGER.info("機関車を作成中... 位置: " + pos);

            // 機関車エンティティを作成
            LocomotiveEntity locomotive = new LocomotiveEntity(ModEntities.LOCOMOTIVE, world);
            locomotive.method_5808(
                    pos.method_10263() + 0.5,
                    pos.method_10264(),
                    pos.method_10260() + 0.5,
                    player.method_36454(),
                    0.0f);

            com.minerailed.MinerailedMod.LOGGER.info("エンティティをスポーン中...");

            // ワールドに追加
            boolean spawned = world.method_8649(locomotive);

            com.minerailed.MinerailedMod.LOGGER.info("スポーン結果: " + spawned);

            // クリエイティブモードでない場合はアイテムを消費
            if (!player.method_31549().field_7477) {
                context.method_8041().method_7934(1);
            }

            return spawned ? class_1269.field_5812 : class_1269.field_5814;
        } catch (Exception e) {
            com.minerailed.MinerailedMod.LOGGER.error("機関車召喚エラー", e);
            return class_1269.field_5814;
        }
    }

    /**
     * 空中で使用したとき
     */
    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);

        // クライアント側では何もしない
        if (world.field_9236) {
            return class_1271.method_22427(stack);
        }

        // プレイヤーの足元に召喚
        class_2338 pos = player.method_24515();

        LocomotiveEntity locomotive = new LocomotiveEntity(ModEntities.LOCOMOTIVE, world);
        locomotive.method_5808(
                pos.method_10263() + 0.5,
                pos.method_10264(),
                pos.method_10260() + 0.5,
                player.method_36454(),
                0.0f);

        world.method_8649(locomotive);

        // クリエイティブモードでない場合はアイテムを消費
        if (!player.method_31549().field_7477) {
            stack.method_7934(1);
        }

        return class_1271.method_22427(stack);
    }
}
