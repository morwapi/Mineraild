package com.minerailed.registry;

import com.minerailed.MinerailedMod;
import com.minerailed.entity.LocomotiveEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1452;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

/**
 * エンティティの登録を管理するクラス
 */
public class ModEntities {

    /**
     * 機関車エンティティタイプ
     */
    public static final class_1299<LocomotiveEntity> LOCOMOTIVE = class_2378.method_10230(
            class_7923.field_41177,
            new class_2960(MinerailedMod.MOD_ID, "locomotive"),
            FabricEntityTypeBuilder.create(class_1311.field_17715, LocomotiveEntity::new)
                    .dimensions(class_4048.method_18385(0.9f, 0.9f)) // 豚と同じサイズ
                    .build());

    /**
     * 全エンティティの登録を実行
     */
    public static void registerEntities() {
        MinerailedMod.LOGGER.info("Minerailed エンティティを登録中...");

        // エンティティ属性の登録（重要！これがないとNullPointerExceptionが発生）
        FabricDefaultAttributeRegistry.register(LOCOMOTIVE, class_1452.method_26890());

        MinerailedMod.LOGGER.info("Minerailed エンティティ登録完了");
    }
}
