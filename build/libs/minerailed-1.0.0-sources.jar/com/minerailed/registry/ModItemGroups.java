package com.minerailed.registry;

import com.minerailed.MinerailedMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_7706;

/**
 * クリエイティブモードのタブにアイテムを追加
 */
public class ModItemGroups {

    /**
     * クリエイティブタブへの登録
     */
    public static void registerItemGroups() {
        MinerailedMod.LOGGER.info("Minerailed アイテムをクリエイティブタブに追加中...");

        // ツールタブに列車召喚アイテムを追加
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(content -> {
            content.method_45421(ModItems.TRAIN_SPAWNER);
        });
    }
}
