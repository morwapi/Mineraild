package com.minerailed.registry;

import com.minerailed.MinerailedMod;
import com.minerailed.item.TrainSpawnerItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * アイテムの登録を管理するクラス
 * 全カスタムアイテムをここで一元管理
 */
public class ModItems {

    /**
     * 列車召喚アイテム
     * 右クリックで基本的な機関車を召喚する
     */
    public static final class_1792 TRAIN_SPAWNER = registerItem("train_spawner",
            new TrainSpawnerItem(new FabricItemSettings().method_7889(1)));

    /**
     * アイテムを登録するヘルパーメソッド
     * 
     * @param name アイテムID（例: "train_spawner"）
     * @param item アイテムインスタンス
     * @return 登録されたアイテム
     */
    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(MinerailedMod.MOD_ID, name), item);
    }

    /**
     * 全アイテムの登録を実行
     * MinerailedMod.onInitialize()から呼び出される
     */
    public static void registerItems() {
        MinerailedMod.LOGGER.info("Minerailed アイテムを登録中...");
        // 上記のstatic初期化により自動的に登録される
    }
}
